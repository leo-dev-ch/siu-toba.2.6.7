
------------------------------------------------------------
-- apex_item_zona
------------------------------------------------------------
INSERT INTO apex_item_zona (proyecto, zona, nombre, clave_editable, archivo, descripcion, consulta_archivo, consulta_clase, consulta_metodo, punto_montaje) VALUES (
	'toba_testing', --proyecto
	'zona_ex_original', --zona
	'zona original', --nombre
	NULL, --clave_editable
	NULL, --archivo
	NULL, --descripcion
	NULL, --consulta_archivo
	NULL, --consulta_clase
	NULL, --consulta_metodo
	'12000005'  --punto_montaje
);
