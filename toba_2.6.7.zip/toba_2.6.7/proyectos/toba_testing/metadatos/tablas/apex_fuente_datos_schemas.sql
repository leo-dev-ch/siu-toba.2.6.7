
------------------------------------------------------------
-- apex_fuente_datos_schemas
------------------------------------------------------------
INSERT INTO apex_fuente_datos_schemas (proyecto, fuente_datos, nombre, principal) VALUES (
	'toba_testing', --proyecto
	'instancia', --fuente_datos
	'desarrollo', --nombre
	'0'  --principal
);
INSERT INTO apex_fuente_datos_schemas (proyecto, fuente_datos, nombre, principal) VALUES (
	'toba_testing', --proyecto
	'perfil_datos', --fuente_datos
	'testing', --nombre
	'0'  --principal
);
INSERT INTO apex_fuente_datos_schemas (proyecto, fuente_datos, nombre, principal) VALUES (
	'toba_testing', --proyecto
	'referencia', --fuente_datos
	'referencia', --nombre
	'0'  --principal
);
