
------------------------------------------------------------
-- apex_conversion
------------------------------------------------------------
INSERT INTO apex_conversion (proyecto, conversion_aplicada, fecha) VALUES (
	'toba_testing', --proyecto
	'0.8.3', --conversion_aplicada
	'2005-11-09 10:59:05.16723'  --fecha
);
INSERT INTO apex_conversion (proyecto, conversion_aplicada, fecha) VALUES (
	'toba_testing', --proyecto
	'0.8.3.1', --conversion_aplicada
	'2005-11-09 10:59:09.232661'  --fecha
);
INSERT INTO apex_conversion (proyecto, conversion_aplicada, fecha) VALUES (
	'toba_testing', --proyecto
	'0.8.3.3', --conversion_aplicada
	'2006-01-04 15:18:58.961991'  --fecha
);
