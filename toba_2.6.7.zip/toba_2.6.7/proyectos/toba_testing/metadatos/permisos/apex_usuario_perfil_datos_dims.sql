
------------------------------------------------------------
-- apex_usuario_perfil_datos_dims
------------------------------------------------------------

--- INICIO Grupo de desarrollo 0
INSERT INTO apex_usuario_perfil_datos_dims (proyecto, usuario_perfil_datos, dimension, elemento, clave) VALUES (
	'toba_testing', --proyecto
	'2', --usuario_perfil_datos
	'10', --dimension
	'12', --elemento
	'1|%-,-%|a'  --clave
);
INSERT INTO apex_usuario_perfil_datos_dims (proyecto, usuario_perfil_datos, dimension, elemento, clave) VALUES (
	'toba_testing', --proyecto
	'2', --usuario_perfil_datos
	'10', --dimension
	'13', --elemento
	'2|%-,-%|a'  --clave
);
INSERT INTO apex_usuario_perfil_datos_dims (proyecto, usuario_perfil_datos, dimension, elemento, clave) VALUES (
	'toba_testing', --proyecto
	'3', --usuario_perfil_datos
	'10', --dimension
	'14', --elemento
	'4|%-,-%|a'  --clave
);
INSERT INTO apex_usuario_perfil_datos_dims (proyecto, usuario_perfil_datos, dimension, elemento, clave) VALUES (
	'toba_testing', --proyecto
	'2', --usuario_perfil_datos
	'11', --dimension
	'15', --elemento
	'1'  --clave
);
INSERT INTO apex_usuario_perfil_datos_dims (proyecto, usuario_perfil_datos, dimension, elemento, clave) VALUES (
	'toba_testing', --proyecto
	'2', --usuario_perfil_datos
	'11', --dimension
	'16', --elemento
	'2'  --clave
);
INSERT INTO apex_usuario_perfil_datos_dims (proyecto, usuario_perfil_datos, dimension, elemento, clave) VALUES (
	'toba_testing', --proyecto
	'3', --usuario_perfil_datos
	'11', --dimension
	'17', --elemento
	'4'  --clave
);
INSERT INTO apex_usuario_perfil_datos_dims (proyecto, usuario_perfil_datos, dimension, elemento, clave) VALUES (
	'toba_testing', --proyecto
	'4', --usuario_perfil_datos
	'7', --dimension
	'18', --elemento
	'3'  --clave
);
INSERT INTO apex_usuario_perfil_datos_dims (proyecto, usuario_perfil_datos, dimension, elemento, clave) VALUES (
	'toba_testing', --proyecto
	'4', --usuario_perfil_datos
	'7', --dimension
	'19', --elemento
	'8'  --clave
);
INSERT INTO apex_usuario_perfil_datos_dims (proyecto, usuario_perfil_datos, dimension, elemento, clave) VALUES (
	'toba_testing', --proyecto
	'4', --usuario_perfil_datos
	'11', --dimension
	'20', --elemento
	'1'  --clave
);
INSERT INTO apex_usuario_perfil_datos_dims (proyecto, usuario_perfil_datos, dimension, elemento, clave) VALUES (
	'toba_testing', --proyecto
	'4', --usuario_perfil_datos
	'11', --dimension
	'21', --elemento
	'2'  --clave
);
INSERT INTO apex_usuario_perfil_datos_dims (proyecto, usuario_perfil_datos, dimension, elemento, clave) VALUES (
	'toba_testing', --proyecto
	'4', --usuario_perfil_datos
	'10', --dimension
	'22', --elemento
	'1|%-,-%|a'  --clave
);
--- FIN Grupo de desarrollo 0
