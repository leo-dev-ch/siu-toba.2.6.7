
------------------------------------------------------------
-- apex_restriccion_funcional
------------------------------------------------------------

--- INICIO Grupo de desarrollo 30
INSERT INTO apex_restriccion_funcional (proyecto, restriccion_funcional, descripcion, permite_edicion) VALUES (
	'toba_testing', --proyecto
	'30000001', --restriccion_funcional
	'Restricciones de Prueba', --descripcion
	'1'  --permite_edicion
);
--- FIN Grupo de desarrollo 30
