
------------------------------------------------------------
-- apex_restriccion_funcional_ei
------------------------------------------------------------
INSERT INTO apex_restriccion_funcional_ei (proyecto, restriccion_funcional, item, objeto, no_visible) VALUES (
	'toba_testing', --proyecto
	'30000001', --restriccion_funcional
	'30000004', --item
	'30000009', --objeto
	'1'  --no_visible
);
