
------------------------------------------------------------
-- apex_restriccion_funcional_ef
------------------------------------------------------------
INSERT INTO apex_restriccion_funcional_ef (proyecto, restriccion_funcional, item, objeto_ei_formulario_fila, objeto_ei_formulario, no_visible, no_editable) VALUES (
	'toba_testing', --proyecto
	'30000001', --restriccion_funcional
	'30000004', --item
	'30000006', --objeto_ei_formulario_fila
	'30000012', --objeto_ei_formulario
	'1', --no_visible
	'0'  --no_editable
);
INSERT INTO apex_restriccion_funcional_ef (proyecto, restriccion_funcional, item, objeto_ei_formulario_fila, objeto_ei_formulario, no_visible, no_editable) VALUES (
	'toba_testing', --proyecto
	'30000001', --restriccion_funcional
	'30000004', --item
	'30000007', --objeto_ei_formulario_fila
	'30000012', --objeto_ei_formulario
	'0', --no_visible
	'1'  --no_editable
);
