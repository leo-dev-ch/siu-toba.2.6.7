
------------------------------------------------------------
-- apex_restriccion_funcional_evt
------------------------------------------------------------
INSERT INTO apex_restriccion_funcional_evt (proyecto, restriccion_funcional, item, evento_id, no_visible) VALUES (
	'toba_testing', --proyecto
	'30000001', --restriccion_funcional
	'30000004', --item
	'30000018', --evento_id
	'1'  --no_visible
);
INSERT INTO apex_restriccion_funcional_evt (proyecto, restriccion_funcional, item, evento_id, no_visible) VALUES (
	'toba_testing', --proyecto
	'30000001', --restriccion_funcional
	'30000004', --item
	'30000028', --evento_id
	'1'  --no_visible
);
