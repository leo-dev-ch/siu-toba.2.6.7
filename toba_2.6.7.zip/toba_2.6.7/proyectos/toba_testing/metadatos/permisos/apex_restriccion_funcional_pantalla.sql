
------------------------------------------------------------
-- apex_restriccion_funcional_pantalla
------------------------------------------------------------
INSERT INTO apex_restriccion_funcional_pantalla (proyecto, restriccion_funcional, item, pantalla, objeto_ci, no_visible) VALUES (
	'toba_testing', --proyecto
	'30000001', --restriccion_funcional
	'30000004', --item
	'30000010', --pantalla
	'30000011', --objeto_ci
	'1'  --no_visible
);
