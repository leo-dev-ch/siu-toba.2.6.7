<?php
class toba_testing_pers_servicio_web extends toba_testing_servicio_web
{
}
?>