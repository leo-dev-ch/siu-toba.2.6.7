<?php
class toba_testing_pers_ei_arbol extends toba_testing_ei_arbol
{
}
?>