<?php
class toba_testing_pers_ei_esquema extends toba_testing_ei_esquema
{
}
?>