<?php
class toba_testing_pers_ei_mapa extends toba_testing_ei_mapa
{
}
?>