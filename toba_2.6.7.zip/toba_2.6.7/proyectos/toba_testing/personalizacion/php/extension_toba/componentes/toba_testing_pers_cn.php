<?php
class toba_testing_pers_cn extends toba_testing_cn
{
}
?>