<?php
class toba_testing_pers_ei_archivos extends toba_testing_ei_archivos
{
}
?>