<?php
class ci_simple extends toba_testing_pers_ci 
{
	function evt__formulario__procesar($datos)
	{
		ei_arbol($datos);
	}
}
?>