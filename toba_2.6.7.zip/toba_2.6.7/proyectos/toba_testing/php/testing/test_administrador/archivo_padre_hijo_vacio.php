<?php

class padre_hijo_vacio
{


}

?>