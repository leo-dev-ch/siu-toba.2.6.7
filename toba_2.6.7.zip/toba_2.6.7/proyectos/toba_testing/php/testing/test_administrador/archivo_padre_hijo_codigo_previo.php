<?php

class padre_hijo_codigo_previo
{


}

?>