<?php 
class la_subclase extends toba_testing_pers_ei_formulario
{
}

?>