<?php
class cn_carga_por_indice extends toba_testing_pers_cn
{
	function test()
	{
		toba::notificacion()->agregar('Test CN! exitoso', 'info');    
	}
}
?>