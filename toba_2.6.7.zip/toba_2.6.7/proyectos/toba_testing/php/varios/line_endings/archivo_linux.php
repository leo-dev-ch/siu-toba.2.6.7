<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class archivo_linux
{
	function get_archivo_linux()
	{
		echo 'Por el poder de Grayskuuuull, Tux  tieeeene el podeeeeeer!!... Tux-man chan chan charan chan! Tux-man XD';
		echo 'La limadura de seso mezclada con azucar hace mal';
	}
}
?>
