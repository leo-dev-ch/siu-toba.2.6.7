<?php
echo 'Archivo realizado con Notepad--';
echo 'Probablemente ni siquiera sepa lo que es un EOL';
echo '\r\n Deberian transformarse en \n comunes ambos \r\n';

class archivo_windows
{

	function get_archivo_windows()
	{
		echo 'Lucha por el Tab!, tiene que estar en 4 posiciones';
		echo 'Windows 7 \r\n Sufrimiento x 7';
	}

}
?>