<?php
class ci_principal extends toba_testing_pers_ci
{
	function conf__cuadro(toba_ei_cuadro $cuadro)
	{
	}

	function evt__cuadro__seleccion($seleccion)
	{
	}

	function evt__cuadro__ordenar($columna, $sentido)
	{
	}

}

?>