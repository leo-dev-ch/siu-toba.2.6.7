<?php
class toba_testing_ei_arbol extends toba_ei_arbol
{
}
?>