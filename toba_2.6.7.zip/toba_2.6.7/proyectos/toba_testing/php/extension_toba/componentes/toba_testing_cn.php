<?php
class toba_testing_cn extends toba_cn
{
}
?>