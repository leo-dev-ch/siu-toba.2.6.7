<?php
class toba_testing_ei_cuadro extends toba_ei_cuadro
{
}
?>