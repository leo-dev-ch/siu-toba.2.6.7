<?php
class toba_testing_servicio_web extends toba_servicio_web
{
}
?>