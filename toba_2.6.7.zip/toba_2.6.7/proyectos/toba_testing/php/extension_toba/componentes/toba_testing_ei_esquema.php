<?php
class toba_testing_ei_esquema extends toba_ei_esquema
{
}
?>