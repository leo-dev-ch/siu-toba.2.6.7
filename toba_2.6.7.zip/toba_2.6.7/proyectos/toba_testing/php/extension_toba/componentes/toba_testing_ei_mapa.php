<?php
class toba_testing_ei_mapa extends toba_ei_mapa
{
}
?>