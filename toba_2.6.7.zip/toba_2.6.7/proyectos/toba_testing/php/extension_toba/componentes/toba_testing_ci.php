<?php
class toba_testing_ci extends toba_ci
{
}
?>