<?php
	echo "PHP PLANO";
?>