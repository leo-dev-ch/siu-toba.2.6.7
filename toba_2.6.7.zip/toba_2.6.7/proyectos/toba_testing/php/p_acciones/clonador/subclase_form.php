<?php 
//--------------------------------------------------------------------
class subclase_form extends toba_testing_pers_ei_formulario
{
	function extender_objeto_js()
	{
	}


}

?>