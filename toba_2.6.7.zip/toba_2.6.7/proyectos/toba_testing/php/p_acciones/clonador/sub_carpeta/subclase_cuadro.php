<?php 
//--------------------------------------------------------------------
class subclase_cuadro extends toba_testing_pers_ei_cuadro
{
	function extender_objeto_js()
	{
	}


}

?>