<?php

class cn extends toba_testing_pers_cn 
{ 
	function evt__procesar_especifico()
	{
		echo "PROCESANDO!!, necesito los datos!!!";
	}

	
}

?>