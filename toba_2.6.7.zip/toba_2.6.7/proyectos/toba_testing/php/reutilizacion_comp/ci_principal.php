<?php

class ci_principal extends toba_testing_pers_ci
{

	function get_datos_editable($clave)
	{
		return "Clave: $clave";	
	}

}

?>