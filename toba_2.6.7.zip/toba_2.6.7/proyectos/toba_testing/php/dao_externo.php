<?php

class dao_externo
{
	function __construct()
	{
	}
	
	function get_data() 
	{
		return array('dato_1', 'dato_2');
	}
}

?>